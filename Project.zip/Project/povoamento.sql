USE helpdesk;

INSERT INTO UNIDADE_SUPORTE (CNPJ, estado, end, nome, Matriz, razao_social, NroFuncionarios) VALUES
('12345678900001', 'SP', 'Rua A, 123', 'Unidade 1', '98765432109876', 'Empresa 1', 50),
('12345678900002', 'RJ', 'Av. B, 456', 'Unidade 2', '98765432109876', 'Empresa 2', 75),
('12345678900003', 'MG', 'Praça C, 789', 'Unidade 3', '23456789012345', 'Empresa 3', 30),
('12345678900004', 'SP', 'Rua D, 1011', 'Unidade 4', '23456789012345', 'Empresa 4', 60),
('12345678900005', 'PR', 'Rua E, 1213', 'Unidade 5', '34567890123456', 'Empresa 5', 20),
('12345678900006', 'RS', 'Av. F, 1415', 'Unidade 6', '34567890123456', 'Empresa 6', 45),
('12345678900007', 'SC', 'Rua G, 1617', 'Unidade 7', '45678901234567', 'Empresa 7', 55),
('12345678900008', 'SP', 'Av. H, 1819', 'Unidade 8', '45678901234567', 'Empresa 8', 90),
('12345678900009', 'RJ', 'Rua I, 2021', 'Unidade 9', '56789012345678', 'Empresa 9', 25),
('12345678900010', 'MG', 'Praça J, 2223', 'Unidade 10', '56789012345678', 'Empresa 10', 70);

-- Povoamento table Supervisor 

INSERT INTO supervisor (Matricula, login, senha, nome, CPF, email, carga_horaria, unidade) VALUES 
(1001, 'joaosilva', '123456', 'João Santos', '11122233344', 'joao.Santos@example.com', 40, '12345678900001'),
(1002, 'mariaalves', 'abcdef', 'Maria Alves', '22233344455', 'maria.alves@example.com', 35, '12345678900002'),
(1003, 'pedrosouza', 'qwerty', 'Pedro Souza', '33344455566', 'pedro.souza@example.com', 30, '12345678900003'),
(1004, 'anacarvalho', '123abc', 'Ana Carvalho', '44455566677', 'ana.carvalho@example.com', 40, '12345678900004'),
(1005, 'felipeazevedo', 'xyz123', 'Felipe Azevedo', '55566677788', 'felipe.azevedo@example.com', 35, '12345678900005'),
(1006, 'juliasantos', '456789', 'Julia Santos', '66677788899', 'julia.santos@example.com', 30, '12345678900006'),
(1007, 'carloslima', 'abc123', 'Carlos Lima', '77788899900', 'carlos.lima@example.com', 40, '12345678900007'),
(1008, 'amandarodrigues', '789xyz', 'Amanda Rodrigues', '88899900011', 'amanda.rodrigues@example.com', 35, '12345678900008'),
(1009, 'renatapereira', 'pqr123', 'Renata Pereira', '99900011122', 'renata.pereira@example.com', 30, '12345678900009'),
(1010, 'lucasoliveira', '456def', 'Lucas Oliveira', '00011122233', 'lucas.oliveira@example.com', 40, '12345678900010');

-- Povoamento table tecnico

INSERT INTO tecnico (Matricula, login, senha, nome, CPF, email, carga_horaria, no_consertos, dias_trabalhados, no_voltas, matric_supervisor, data_inicio, unidade)
VALUES 
(0001, 'tecnico1', 'senha1', 'João Silva', '11122233344', 'joao.silva@email.com', 40, 5, 20, 2, 1010, '2022-02-01', '12345678900001'),
(0002, 'tecnico2', 'senha2', 'Maria Souza', '22233344455', 'maria.souza@email.com', 40, 8, 22, 4, 1010, '2022-03-09', '12345678900002'),
(0003, 'tecnico3', 'senha3', 'Pedro Santos', '33344455566', 'pedro.santos@email.com', 40, 10, 25, 3, 1001, '2022-05-08', '12345678900003'),
(0004, 'tecnico4', 'senha4', 'Ana Oliveira', '44455566677', 'ana.oliveira@email.com', 40, 6, 18, 1, 1001, '2022-01-20', '12345678900004'),
(0005, 'tecnico5', 'senha5', 'Fernando Silva', '55566677788', 'fernando.silva@email.com', 40, 9, 23, 5, 1002, '2022-11-11', '12345678900005'),
(0006, 'tecnico6', 'senha6', 'Juliana Santos', '66677788899', 'juliana.santos@email.com', 40, 7, 21, 3, 1002, '2022-01-30', '12345678900006'),
(0007, 'tecnico7', 'senha7', 'Márcio Almeida', '77788899900', 'marcio.almeida@email.com', 40, 12, 27, 6, 1003, '2022-03-20', '12345678900007'),
(0008, 'tecnico8', 'senha8', 'Camila Lima', '88899900011', 'camila.lima@email.com', 40, 4, 15, 2, 1003, '2022-01-30', '12345678900008'),
(0009, 'tecnico9', 'senha9', 'Rafaela Sousa', '99900011122', 'rafaela.sousa@email.com', 40, 11, 26, 4, 1004, '2022-02-28', '12345678900009'),
(0010, 'tecnico10', 'senha10', 'Gustavo Silva', '00011122233', 'gustavo.silva@email.com', 40, 5, 19, 1, 1004, '2022-07-07', '12345678900010');


-- Povoamento kpi

INSERT INTO kpi (matric_tec, Sequencial, KPI_1, dsc_KPI_1, KPI_2, dsc_KPI_2)
VALUES 
(0001, 1, 10, 'Número de vendas', 20, 'Valor total das vendas'),
(0002, 2, 8, 'Tempo médio de atendimento', 15, 'Satisfação do cliente'),
(0003, 1, 5, 'Número de chamados resolvidos', 10, 'Tempo médio de resolução'),
(0004, 2, 6, 'Nível de aderência ao SLA', 12, 'Taxa de resolução no primeiro contato'),
(0005, 1, 15, 'Número de novos clientes', 25000, 'Receita total'),
(0006, 2, 80, 'Taxa de conversão', 30, 'Custo de aquisição do cliente'),
(0007, 1, 50, 'Retorno sobre o investimento', 100, 'Margem de lucro'),
(0008, 2, 200, 'Custo por clique', 500, 'Taxa de conversão'),
(0009, 1, 12, 'Tempo médio de resposta', 20, 'Número de tickets abertos'),
(0010, 2, 7, 'Taxa de resolução', 90, 'Índice de satisfação do cliente');

-- Povoamento table cliente_pj

INSERT INTO cliente_pj (Cod, prioridade, endereco, estado, fone, email, cnpj, razao_social)
VALUES
(1111, 3, 'Rua A, 123', 'SP', '1199999999', 'cliente1@exemplo.com', '12345678901234', 'Empresa 1'),
(2222, 2, 'Rua B, 456', 'RJ', '2199999999', 'cliente2@exemplo.com', '23456789012345', 'Empresa 2'),
(3333, 1, 'Rua C, 789', 'MG', '3199999999', 'cliente3@exemplo.com', '34567890123456', 'Empresa 3'),
(4444, 3, 'Rua D, 1011', 'RS', '5199999999', 'cliente4@exemplo.com', '45678901234567', 'Empresa 4'),
(5555, 2, 'Rua E, 1213', 'SP', '1199999998', 'cliente5@exemplo.com', '56789012345678', 'Empresa 5'),
(6666, 1, 'Rua F, 1415', 'RJ', '2199999998', 'cliente6@exemplo.com', '67890123456789', 'Empresa 6'),
(7777, 3, 'Rua G, 1617', 'MG', '3199999998', 'cliente7@exemplo.com', '78901234567890', 'Empresa 7'),
(8888, 2, 'Rua H, 1819', 'RS', '5199999998', 'cliente8@exemplo.com', '89012345678901', 'Empresa 8'),
(9999, 1, 'Rua I, 2021', 'SP', '1199999997', 'cliente9@exemplo.com', '90123456789012', 'Empresa 9'),
(0000, 3, 'Rua J, 2223', 'RJ', '2199999997', 'cliente10@exemplo.com', '01234567890123', 'Empresa 10');

-- Povoamento table fatura

INSERT INTO fatura (cod, n_parcelas, vl_total, status, cod_cliente_pj)
VALUES
(1511, 2, 100.00, 'Pendente', 1111),
(1512, 3, 150.50, 'Pago', 2222),
(1513, 1, 50.00, 'Pendente', 3333),
(1514, 6, 500.00, 'Pago', 4444),
(1515, 4, 200.00, 'Pago', 5555),
(1516, 2, 1000.00, 'Pendente', 6666),
(1517, 3, 300.50, 'Pendente', 7777),
(1518, 1, 100.00, 'Pago', 8888),
(1519, 5, 800.00, 'Pendente', 9999),
(1510, 4, 250.00, 'Pago', 0000);


-- Povoamento table chamado

INSERT INTO chamado (Seq, Prioridade, Complexidade, descricao, status, tipo, cod_plano, mat_supervisor, mat_tec, cod_cliente_pj, data) 
VALUES 

(5001, 1, 3, 'Problema de conexão com a internet', 'Aberto', 'Técnico', 123, 1010, 0001, 0000, '2022-01-15'),
(5002, 2, 2, 'Problema com a impressora', 'Aberto', 'Técnico', 123, 1001, 0002, 9999, '2022-02-12'),
(5003, 3, 1, 'Solicitação de instalação de software', 'Aberto', 'Suporte', 124, 1002, 0003, 8888, '2022-03-05'),
(5004, 1, 2, 'Problema com o sistema operacional', 'Fechado', 'Técnico', 125, 1003, 0004, 7777, '2022-03-10'),
(5005, 2, 3, 'Solicitação de treinamento', 'Aberto', 'Suporte', 126, 1004, 0005, 6666, '2022-04-02'),
(5006, 3, 1, 'Problema com o email', 'Fechado', 'Técnico', 123, 1005, 0006, 5555, '2022-04-07'),
(5007, 1, 2, 'Solicitação de licença de software', 'Aberto', 'Suporte', 127, 1006, 0007, 4444, '2022-05-01'),
(5008, 2, 3, 'Problema com o servidor', 'Aberto', 'Técnico', 128, 1007, 0008, 3333, '2022-05-15'),
(5009, 3, 1, 'Solicitação de atualização de software', 'Fechado', 'Suporte', 129, 1008, 0009, 2222, '2022-06-02'),
(5010, 1, 2, 'Problema com a rede', 'Fechado', 'Técnico', 130, 1009, 0010, 1111, '2022-06-10');


-- Povoamento table orçamento

INSERT INTO orcamento (COD, DATA_ABERTURA, DT_EMISSAO, DESCRICAO, VALIDADE_N_DIAS, ULTIMA_DATA)
VALUES
(3001, '2022-01-01', '2022-01-05', 'Orçamento para aquisição de Placa', 30, '2022-01-31'),
(3002, '2022-02-01', '2022-02-05', 'Orçamento para compra de material para manutenção', 15, '2022-02-20'),
(3003, '2022-03-01', '2022-03-10', 'Orçamento para serviços de limpeza', 60, '2022-05-10'),
(3004, '2022-04-01', '2022-04-05', 'Orçamento para aquisição de equipamentos de informática', 30, '2022-05-05'),
(3005, '2022-05-01', '2022-05-05', 'Orçamento para conserto da estrutura do equipamento', 90, '2022-07-30'),
(3006, '2022-06-01', '2022-06-05', 'Orçamento para atendimento homeOff', 15, '2022-06-20'),
(3007, '2022-07-01', '2022-07-05', 'Orçamento para contratação de serviços', 30, '2022-08-05'),
(3008, '2022-08-01', '2022-08-05', 'Orçamento para Analisar atividade', 15, '2022-08-20'),
(3009, '2022-09-01', '2022-09-05', 'Orçamento para contratação de serviços externo', 30, '2022-10-05'),
(3010, '2022-10-01', '2022-10-05', 'Orçamento para aquisição de software de gestão', 60, '2022-12-05');

-- Povoamento table  ordem_serviço

INSERT INTO ordem_servico(numero, status, data_criacao, prazo_entrega_em_dias, dt_devida, cod_orcamento, cod_fatura, cod_chamado)
VALUES 

(9001, 'Aberto', '2023-03-18', 5, '2023-03-23', 3001, 1511, 5001),
(9002, 'Fechado', '2023-03-15', 3, '2023-03-18', 3002, 1512, 5002),
(9003, 'Pendente', '2023-03-10', 10, '2023-03-20', 3003, 1513, 5003),
(9004, 'Em Andamento', '2023-03-08', 7, '2023-03-15', 3004, 1514,5004),
(9005, 'Aberto', '2023-03-17', 2, '2023-03-19', 3005, 1515, 5005),
(9006, 'Fechado', '2023-03-12', 4, '2023-03-16', 3006, 1516, 5006),
(9007, 'Pendente', '2023-03-09', 8, '2023-03-17', 3007, 1517, 5007),
(9008, 'Em Andamento', '2023-03-07', 6, '2023-03-13', 3008, 1518, 5008),
(9009, 'Aberto', '2023-03-16', 1, '2023-03-17', 3009, 1519, 5009),
(9010, 'Fechado', '2023-03-14', 2, '2023-03-16', 3010, 1510, 5010);

-- Povoamento table tipo_serviço

INSERT INTO tipo_servico (COD, DESCRICAO)
VALUES (7001, 'Limpeza de placa'),
       (7002, 'Teste de hardware'),
       (7003, 'Montagem de equipamente'),
       (7004, 'Manutenção elétrica'),
       (7005, 'Manutenção elétronica'),
       (7006, 'Modelagem de circuitos'),
       (7007, 'Serviços de limpeza de componetes'),
       (7008, 'Restauração de placas'),
       (7009, 'Consultoria de negócios'),
       (7010, 'Serviços de informática');

-- Povoamento  table serviço

INSERT INTO servico (cod, descricao, status, valor, cod_tipo_servico, num_serv, nivel_urgencia)
VALUES 
(8001, 'Manutenção de impressora', 'Pendente', 250.00, 7001, 9001, 3),
(8002, 'Formatação de computador', 'Concluído', 150.00, 7002, 9002, 2),
(8003, 'Instalação de software', 'Pendente', 80.00, 7003, 9003, 1),
(8004, 'Configuração de rede', 'Pendente', 300.00, 7004, 9004, 3),
(8005, 'Substituição de placa mãe', 'Concluído', 500.00, 7005, 9005, 2),
(8006, 'Recuperação de dados', 'Pendente', 200.00, 7006, 9006, 1),
(8007, 'Atualização de sistema operacional', 'Pendente', 120.00, 7003, 9007, 2),
(8008, 'Troca de tela de notebook', 'Concluído', 350.00, 7005, 9008, 3),
(8009, 'Limpeza de vírus', 'Concluído', 100.00, 7002, 9009, 1),
(8010, 'Instalação de antivírus', 'Pendente', 60.00, 7003,9010, 2);


-- Povoamento table contrato

INSERT INTO contrato (COD, DT_FIM, STATUS, DT_INICIO, PERIODO_CONTRATO_EM_DIAS, COD_CLIENTE_PJ, COD_UNIDADE) 
VALUES
(6001, '2023-12-31', 'Ativo', '2021-01-01', 730, 1111, '12345678900001'),
(6002, '2024-06-30', 'Ativo', '2022-01-01', 546, 2222, '12345678900002'),
(6003, '2023-12-31', 'Encerrado', '2021-01-01', 730, 3333, '12345678900003'),
(6004, '2022-12-31', 'Encerrado', '2021-01-01', 365, 4444, '12345678900004'),
(6005, '2023-09-30', 'Ativo', '2021-01-01', 637, 5555, '12345678900005'),
(6006, '2024-12-31', 'Ativo', '2022-01-01', 731, 6666, '12345678900006'),
(6007, '2023-12-31', 'Encerrado', '2021-01-01', 730, 7777, '12345678900007'),
(6008, '2024-06-30', 'Ativo', '2022-01-01', 546, 8888, '12345678900008'),
(6009, '2023-12-31', 'Encerrado', '2021-01-01', 730, 9999, '12345678900009'),
(6010, '2023-09-30', 'Ativo', '2021-01-01', 637, 0000, '12345678900010');



-- Povoamento table computador

INSERT INTO computador (COD, ESTADO, FABRICANTE, DATA_ENTRADA, SETOR, DESCRICAO, HISTORICO, BIOS_FABRIC, VERSAO_BIOS, NOME_SO, VERSAO_SO, END_IP, TIPO, COD_CONTRATO)
VALUES
(5401, 'Em uso', 'Dell', '2022-01-05', 'TI', 'Computador desktop Dell Optiplex 7010', 'Manutenção realizada em 2022-02-01', 'Dell', 'A18', 'Windows', '10.0.18363', '192.168.0.10', 'Desktop', 6001),
(5402, 'Em uso', 'HP', '2022-01-10', 'RH', 'Notebook HP Elitebook 840 G3', 'Sem histórico de manutenção', 'HP', 'Q78', 'Windows', '10.0.18363', '192.168.0.11', 'Notebook', 6002),
(5403, 'Em uso', 'Lenovo', '2022-02-05', 'Financeiro', 'Computador desktop Lenovo ThinkCentre M720s', 'Manutenção realizada em 2022-03-01', 'Lenovo', 'ECKT35A', 'Windows', '10.0.18363', '192.168.0.12', 'Desktop', 6004),
(5404, 'Em uso', 'Dell', '2022-02-10', 'Vendas', 'Notebook Dell Latitude 5490', 'Manutenção realizada em 2022-03-05', 'Dell', 'A18', 'Windows', '10.0.18363', '192.168.0.13', 'Notebook', 6003),
(5405, 'Em uso', 'HP', '2022-03-01', 'Marketing', 'Computador desktop HP EliteDesk 800 G4', 'Sem histórico de manutenção', 'HP', 'Q78', 'Windows', '10.0.18363', '192.168.0.14', 'Desktop', 6005),
(5406, 'Fora de uso', 'Lenovo', '2022-03-05', 'Financeiro', 'Notebook Lenovo ThinkPad T440', 'Substituído em 2022-04-01', 'Lenovo', 'GIET90WW', 'Windows', '10.0.18363', '192.168.0.15', 'Notebook', 6006),
(5407, 'Em uso', 'Dell', '2022-04-01', 'Compras', 'Computador desktop Dell Optiplex 3070', 'Sem histórico de manutenção', 'Dell', 'A25', 'Windows', '10.0.18363', '192.168.0.16', 'Desktop', 6007),
(5408, 'Em uso', 'HP', '2022-05-01', 'TI', 'Notebook HP ProBook 440 G8', 'Sem histórico de manutenção', 'HP', 'Q05', 'Windows', '10.0.18363', '192.168.0.17', 'Notebook', 6008),
(5409, 'Em uso', 'Dell', '2022-01-05', 'TI', 'Computador desktop Dell Optiplex 7010', 'Manutenção realizada em 2022-02-01', 'Dell', 'A18', 'Windows', '10.0.18363', '192.168.0.10', 'Desktop', 6009),
(5410, 'Em uso', 'HP', '2022-03-10', 'RH', 'Notebook HP Elitebook 840 G3', 'Sem histórico de manutenção', 'HP', 'Q78', 'Windows', '10.0.18363', '192.168.0.12', 'Notebook', 6010);

-- Povoamento table impressora

INSERT INTO impressora (COD, ESTADO, FABRICANTE, DATA_ENTRADA, SETOR, DESCRICAO, HISTORICO, MODELO, COD_CONTRATO)
VALUES 

 (5301, 'Bom', 'HP', '2022-01-15', 'RH', 'Impressora a laser', 'Manutenção realizada em janeiro de 2023', 'LaserJet Pro MFP M426fdw', 6001),
 (5302, 'Ruim', 'Brother', '2021-06-01', 'Financeiro', 'Impressora a jato de tinta', 'Precisa de manutenção', 'MFC-J6935DW', 6002),
 (5303, 'Bom', 'Epson', '2021-12-01', 'TI', 'Impressora matricial', 'Sem histórico de manutenção', 'LQ-590II', 6003),
 (5304, 'Bom', 'Samsung', '2022-02-01', 'Compras', 'Impressora a laser colorida', 'Manutenção realizada em fevereiro de 2023', 'Xpress C430W', 6004),
 (5305, 'Ruim', 'Lexmark', '2022-03-01', 'Marketing', 'Impressora a jato de tinta', 'Precisa de manutenção', 'CX517de', 6005),
 (5306, 'Bom', 'Canon', '2021-09-01', 'Jurídico', 'Impressora a laser', 'Manutenção realizada em março de 2022', 'imageRUNNER ADVANCE C256i III', 6006),
 (5307, 'Bom', 'Xerox', '2022-02-15', 'RH', 'Impressora multifuncional a laser', 'Manutenção realizada em fevereiro de 2023', 'WorkCentre 6515', 6007),
 (5308, 'Bom', 'Dell', '2021-11-15', 'TI', 'Impressora a jato de tinta', 'Manutenção realizada em dezembro de 2021', 'V525w', 6008),
 (5309, 'Bom', 'Dell', '2021-11-15', 'TI', 'Impressora a jato de tinta', 'Manutenção realizada em dezembro de 2021', 'V525w',6009),
 (5310, 'Bom', 'Ricoh', '2022-02-28', 'Administração', 'Impressora multifuncional a laser', 'Manutenção realizada em março de 2023', 'SP C261SFNw', 6010);


-- Povoamento table componente

INSERT INTO COMPONENTE (COD, ONBOARD, TIPO, MODELO, FABRICANTE) VALUES
    (5501, 'Sim', 'Placa de vídeo', 'GeForce GTX 1080', 'Nvidia'),
    (5502, 'Não', 'Processador', 'Core i7-8700K', 'Intel'),
    (5503, 'Não', 'Placa-mãe', 'ROG Strix Z370-F', 'Asus'),
    (5504, 'Sim', 'Memória RAM', 'Corsair Vengeance LPX 16GB', 'Corsair'),
    (5505, 'Não', 'HD', 'Seagate Barracuda 2TB', 'Seagate'),
    (5506, 'Sim', 'Fonte de alimentação', 'EVGA 650W', 'EVGA'),
    (5507, 'Não', 'Gabinete', 'NZXT H510i', 'NZXT'),
    (5508, 'Não', 'Monitor', 'Dell S2716DG', 'Dell'),
    (5509, 'Não', 'Teclado', 'Logitech G910 Orion Spectrum', 'Logitech'),
    (5510, 'Não', 'Mouse', 'Logitech G502 Hero', 'Logitech');

-- Povoamento table driver

INSERT INTO driver (COD_COMPONENTE, SEQUENCIAL, CAMINHO)
VALUES 
       (5501, 1, 'C:/drivers/audio/'),
       (5502, 2, 'C:/drivers/video/'),
       (5503, 3, 'C:/drivers/rede/'),
       (5504, 1, 'D:/drivers/audio/'),
       (5505, 2, 'D:/drivers/video/'),
       (5506, 1, 'E:/drivers/rede/'),
       (5507, 2, 'E:/drivers/audio/'),
       (5508, 3, 'E:/drivers/video/'),
       (5509, 4, 'E:/drivers/outros/'),
       (5510, 1, 'F:/drivers/video/');


-- Povoamento table drive_impressora

INSERT INTO driver_impressora (COD_IMPRESSORA, COD_DRIVER, VERSAO, CAMINHO, IMPRESSORA)
VALUES 
(05301, 5501, 'v1.0', 'C:\drivers\printer1', 5301),
(05302, 5502, 'v2.0', 'C:\drivers\printer1', 5301),
(05303, 5503, 'v3.5', 'C:\drivers\printer2', 5302),
(05304, 5504, 'v4.0', 'C:\drivers\printer2', 5302),
(05305, 5505, 'v1.2', 'C:\drivers\printer3', 5303),
(05306, 5506, 'v2.1', 'C:\drivers\printer3', 5303),
(05307, 5507, 'v2.0', 'C:\drivers\printer4', 5304),
(05308, 5508, 'v3.0', 'C:\drivers\printer4', 5304),
(05309, 5509, 'v1.0', 'C:\drivers\printer5', 5305),
(05310, 5510, 'v2.0', 'C:\drivers\printer5', 5305);




-- Povoamento table POSSUI_COMPONENTE_COMPUTADOR

INSERT INTO possui_componente_computador (cod_comp, cod_computador)
VALUES 
    (5501, 5410),
    (5502, 5409),
    (5503, 5408),
    (5504, 5407),
    (5505, 5406),
    (5506, 5405),
    (5507, 5404),
    (5508, 5403),
    (5509, 5402),
    (5510, 5401);
-- Povoamento table ENVOLVEU_ORDEM_SERVICO_IMPRESSORA

INSERT INTO envolveu_ordem_servico_impressora (cod_impressora, num_ordem)
VALUES 
(5301, 9010),
(5301, 9009),
(5302, 9008),
(5303, 9007),
(5304, 9006),
(5305, 9005),
(5306, 9004),
(5307, 9003),
(5308, 9002),
(5309, 9001);










