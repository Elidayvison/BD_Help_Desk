USE helpdesk ;

DELIMITER $$
CREATE FUNCTION verificar_fatura(num_fatura INT) RETURNS VARCHAR(100)
deterministic
BEGIN
    DECLARE ordem_status VARCHAR(20);
    DECLARE fatura_status VARCHAR(20);
    declare numero_os int;
    SELECT os.status, os.numero INTO ordem_status, numero_os FROM ORDEM_SERVICO os WHERE os.cod_fatura = num_fatura;
    SELECT f.status INTO fatura_status FROM FATURA f WHERE f.cod = num_fatura;
    
    IF ordem_status = 'fechado' AND fatura_status = 'pendente' THEN
        RETURN CONCAT('Fatura número ', num_fatura, ' deve ser emitida ordem de serviço número  ', numero_os  , ' esta concluida.');
    ELSEIF ordem_status != 'fechado' THEN
        RETURN concat('Ordem de serviço  ' , numero_os , ' não está concluida fatura não pode ser emitida.');
    ELSE
        RETURN 'Fatura já emitida ou não encontrada.';
    END IF;
END$$
DELIMITER ;

select verificar_fatura(2);
select verificar_fatura(5);
select verificar_fatura(12);
select * from fatura;


delimiter $$
CREATE FUNCTION contrato_em_dia(cod_cliente INT) RETURNS varchar(100)
deterministic
begin
DECLARE v_dt_fim DATE;

SELECT dt_fim INTO v_dt_fim FROM contrato WHERE COD_CLIENTE_PJ = cod_cliente ;
    IF v_dt_fim < curdate() THEN
         RETURN CONCAT(' Contrato número ' , cod_cliente , ' esta vencido.');
    elseif v_dt_fim >= curdate() then
		return concat(' Contrato número ', cod_cliente , ' esta em dia.');
    ELSE
        RETURN concat('Contrato Inesistente');
    END IF;
END $$
 delimiter ;
 
select contrato_em_dia(5);
select contrato_em_dia(3);
select contrato_em_dia(15);
select * from contrato;

select verificar_pagamento(10);
 select verificar_pagamento(3);
 select verificar_pagamento(13);
delimiter %%
 create function verificar_pagamento ( cod_cliente int) returns varchar (100)
 deterministic
 begin
 declare fatura_num  int;
 declare parcelas_num int;
 declare situacao_pag varchar(15);
 select f.cod, f.n_parcelas, f.status into fatura_num, parcelas_num, situacao_pag from fatura  f where f.cod_cliente_pj = cod_cliente order by cod desc limit 1 ;
	if situacao_pag = 'pago' then
    return concat('Cliente cod  ' , cod_cliente, ' esta adimplete');
    elseif situacao_pag != 'pago' then
    return concat('Cliente cod  ' , cod_cliente, ' esta inadimplete com ' , parcelas_num, ' parcela(s) em aberto/pendente');
    else
    return 'Cliente Inesistente ou sem fatura. ';
    end if;
end %%
delimiter;




DELIMITER //
CREATE FUNCTION ordens_servico_em_atraso(sit varchar(10)) RETURNS varchar(250)
deterministic
begin
declare result varchar(1000);
 select result= os.numero, os.ststus, os.data_criacao, os.prazo_entrega_em_dias, os.dt_devida from ordem_servico where os.dt_devida < curdate();
return result;
END //
DELIMITER ;



select * from ordem_servico as os where  os.dt_devida < curdate();
 
delimiter %%
 CREATE PROCEDURE ordens_servico_em_atraso()
BEGIN

    SELECT os.numero, os.status, os.data_criacao, os.prazo_entrega_em_dias, os.dt_devida
    FROM ordem_servico os
    WHERE os.dt_devida < CURDATE();
END%%





 call ordens_servico_em_atraso