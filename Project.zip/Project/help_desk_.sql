CREATE DATABASE  IF NOT EXISTS `helpdesk` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `helpdesk`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: helpdesk
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chamado`
--

DROP TABLE IF EXISTS `chamado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chamado` (
  `Seq` int NOT NULL,
  `Prioridade` int NOT NULL,
  `Complexidade` int NOT NULL,
  `descricao` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `cod_plano` int NOT NULL,
  `mat_supervisor` int NOT NULL,
  `mat_tec` int NOT NULL,
  `cod_cliente_pj` int NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`Seq`),
  KEY `mat_supervisor` (`mat_supervisor`),
  KEY `mat_tec` (`mat_tec`),
  KEY `cod_cliente_pj` (`cod_cliente_pj`),
  CONSTRAINT `chamado_ibfk_1` FOREIGN KEY (`mat_supervisor`) REFERENCES `supervisor` (`Matricula`),
  CONSTRAINT `chamado_ibfk_2` FOREIGN KEY (`mat_tec`) REFERENCES `tecnico` (`Matricula`),
  CONSTRAINT `chamado_ibfk_3` FOREIGN KEY (`cod_cliente_pj`) REFERENCES `cliente_pj` (`Cod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chamado`
--

LOCK TABLES `chamado` WRITE;
/*!40000 ALTER TABLE `chamado` DISABLE KEYS */;
INSERT INTO `chamado` VALUES (1,1,3,'Problema de conexão com a internet','Aberto','Técnico',123,1,1,1,'2022-01-15'),(2,2,2,'Problema com a impressora','Aberto','Técnico',123,2,2,2,'2022-02-12'),(3,3,1,'Solicitação de instalação de software','Aberto','Suporte',124,3,3,3,'2022-03-05'),(4,1,2,'Problema com o sistema operacional','Fechado','Técnico',125,3,4,4,'2022-03-10'),(5,2,3,'Solicitação de treinamento','Aberto','Suporte',126,4,5,5,'2022-04-02'),(6,3,1,'Problema com o email','Fechado','Técnico',123,5,6,6,'2022-04-07'),(7,1,2,'Solicitação de licença de software','Aberto','Suporte',127,6,7,7,'2022-05-01'),(8,2,3,'Problema com o servidor','Aberto','Técnico',128,7,8,8,'2022-05-15'),(9,3,1,'Solicitação de atualização de software','Fechado','Suporte',129,8,9,9,'2022-06-02'),(10,1,2,'Problema com a rede','Fechado','Técnico',130,9,10,10,'2022-06-10');
/*!40000 ALTER TABLE `chamado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_pj`
--

DROP TABLE IF EXISTS `cliente_pj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente_pj` (
  `Cod` int NOT NULL,
  `prioridade` int NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `estado` char(2) NOT NULL,
  `fone` char(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cnpj` char(14) NOT NULL,
  `razao_social` varchar(50) NOT NULL,
  PRIMARY KEY (`Cod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_pj`
--

LOCK TABLES `cliente_pj` WRITE;
/*!40000 ALTER TABLE `cliente_pj` DISABLE KEYS */;
INSERT INTO `cliente_pj` VALUES (0,3,'Rua J, 2223','RJ','2199999997','cliente10@exemplo.com','01234567890123','Empresa 10'),(1111,3,'Rua A, 123','SP','1199999999','cliente1@exemplo.com','12345678901234','Empresa 1'),(2222,2,'Rua B, 456','RJ','2199999999','cliente2@exemplo.com','23456789012345','Empresa 2'),(3333,1,'Rua C, 789','MG','3199999999','cliente3@exemplo.com','34567890123456','Empresa 3'),(4444,3,'Rua D, 1011','RS','5199999999','cliente4@exemplo.com','45678901234567','Empresa 4'),(5555,2,'Rua E, 1213','SP','1199999998','cliente5@exemplo.com','56789012345678','Empresa 5'),(6666,1,'Rua F, 1415','RJ','2199999998','cliente6@exemplo.com','67890123456789','Empresa 6'),(7777,3,'Rua G, 1617','MG','3199999998','cliente7@exemplo.com','78901234567890','Empresa 7'),(8888,2,'Rua H, 1819','RS','5199999998','cliente8@exemplo.com','89012345678901','Empresa 8'),(9999,1,'Rua I, 2021','SP','1199999997','cliente9@exemplo.com','90123456789012','Empresa 9');
/*!40000 ALTER TABLE `cliente_pj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `componente`
--

DROP TABLE IF EXISTS `componente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `componente` (
  `COD` int NOT NULL,
  `ONBOARD` varchar(20) NOT NULL,
  `TIPO` varchar(50) NOT NULL,
  `MODELO` varchar(50) NOT NULL,
  `FABRICANTE` varchar(50) NOT NULL,
  PRIMARY KEY (`COD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `componente`
--

LOCK TABLES `componente` WRITE;
/*!40000 ALTER TABLE `componente` DISABLE KEYS */;
INSERT INTO `componente` VALUES (1,'Sim','Placa de vídeo','GeForce GTX 1080','Nvidia'),(2,'Não','Processador','Core i7-8700K','Intel'),(3,'Não','Placa-mãe','ROG Strix Z370-F','Asus'),(4,'Sim','Memória RAM','Corsair Vengeance LPX 16GB','Corsair'),(5,'Não','HD','Seagate Barracuda 2TB','Seagate'),(6,'Sim','Fonte de alimentação','EVGA 650W','EVGA'),(7,'Não','Gabinete','NZXT H510i','NZXT'),(8,'Não','Monitor','Dell S2716DG','Dell'),(9,'Não','Teclado','Logitech G910 Orion Spectrum','Logitech'),(10,'Não','Mouse','Logitech G502 Hero','Logitech');
/*!40000 ALTER TABLE `componente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `computador`
--

DROP TABLE IF EXISTS `computador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `computador` (
  `COD` int NOT NULL,
  `ESTADO` varchar(20) NOT NULL,
  `FABRICANTE` varchar(50) NOT NULL,
  `DATA_ENTRADA` date NOT NULL,
  `SETOR` varchar(50) NOT NULL,
  `DESCRICAO` varchar(100) NOT NULL,
  `HISTORICO` varchar(100) NOT NULL,
  `BIOS_FABRIC` varchar(50) NOT NULL,
  `VERSAO_BIOS` varchar(20) NOT NULL,
  `NOME_SO` varchar(50) NOT NULL,
  `VERSAO_SO` varchar(20) NOT NULL,
  `END_IP` varchar(20) NOT NULL,
  `TIPO` varchar(20) NOT NULL,
  `COD_CONTRATO` int NOT NULL,
  PRIMARY KEY (`COD`),
  KEY `COD_CONTRATO` (`COD_CONTRATO`),
  CONSTRAINT `computador_ibfk_1` FOREIGN KEY (`COD_CONTRATO`) REFERENCES `contrato` (`COD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `computador`
--

LOCK TABLES `computador` WRITE;
/*!40000 ALTER TABLE `computador` DISABLE KEYS */;
INSERT INTO `computador` VALUES (1,'Bom','Dell','2022-01-05','TI','Computador desktop Dell Optiplex 7010','Manutenção realizada em 2022-02-01','Dell','A18','Windows','10.0.18363','192.168.0.10','Desktop',1),(2,'Bom','HP','2022-01-10','RH','Notebook HP Elitebook 840 G3','Sem histórico de manutenção','HP','Q78','Windows','10.0.18363','192.168.0.11','Notebook',2),(3,'Bom','Lenovo','2022-02-05','Financeiro','Computador desktop Lenovo ThinkCentre M720s','Manutenção realizada em 2022-03-01','Lenovo','ECKT35A','Windows','10.0.18363','192.168.0.12','Desktop',1),(4,'Bom','Dell','2022-02-10','Vendas','Notebook Dell Latitude 5490','Manutenção realizada em 2022-03-05','Dell','A18','Windows','10.0.18363','192.168.0.13','Notebook',5),(5,'Ruim','HP','2022-03-01','Marketing','Computador desktop HP EliteDesk 800 G4','Sem histórico de manutenção','HP','Q78','Windows','10.0.18363','192.168.0.14','Desktop',6),(6,'Ruim','Lenovo','2022-03-05','Financeiro','Notebook Lenovo ThinkPad T440','Substituído em 2022-04-01','Lenovo','GIET90WW','Windows','10.0.18363','192.168.0.15','Notebook',4),(7,'Bom','Dell','2022-04-01','Compras','Computador desktop Dell Optiplex 3070','Sem histórico de manutenção','Dell','A25','Windows','10.0.18363','192.168.0.16','Desktop',5),(8,'Ruim','HP','2022-05-01','TI','Notebook HP ProBook 440 G8','Sem histórico de manutenção','HP','Q05','Windows','10.0.18363','192.168.0.17','Notebook',8),(9,'Bom','Dell','2022-01-05','TI','Computador desktop Dell Optiplex 7010','Manutenção realizada em 2022-02-01','Dell','A18','Windows','10.0.18363','192.168.0.10','Desktop',4),(10,'Ruim','HP','2022-03-10','RH','Notebook HP Elitebook 840 G3','Sem histórico de manutenção','HP','Q78','Windows','10.0.18363','192.168.0.12','Notebook',2);
/*!40000 ALTER TABLE `computador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contrato`
--

DROP TABLE IF EXISTS `contrato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contrato` (
  `COD` int NOT NULL,
  `DT_FIM` date NOT NULL,
  `STATUS` varchar(20) NOT NULL,
  `DT_INICIO` date NOT NULL,
  `PERIODO_CONTRATO_EM_DIAS` int NOT NULL,
  `COD_CLIENTE_PJ` int NOT NULL,
  `COD_UNIDADE` char(14) NOT NULL,
  PRIMARY KEY (`COD`),
  KEY `COD_CLIENTE_PJ` (`COD_CLIENTE_PJ`),
  KEY `COD_UNIDADE` (`COD_UNIDADE`),
  CONSTRAINT `contrato_ibfk_1` FOREIGN KEY (`COD_CLIENTE_PJ`) REFERENCES `cliente_pj` (`Cod`),
  CONSTRAINT `contrato_ibfk_2` FOREIGN KEY (`COD_UNIDADE`) REFERENCES `unidade_suporte` (`CNPJ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrato`
--

LOCK TABLES `contrato` WRITE;
/*!40000 ALTER TABLE `contrato` DISABLE KEYS */;
INSERT INTO `contrato` VALUES (6001,'2023-12-31','Ativo','2021-01-01',730,1111,'12345678900001'),(6002,'2024-06-30','Ativo','2022-01-01',546,2222,'12345678900002'),(6003,'2023-12-31','Encerrado','2021-01-01',730,3333,'12345678900003'),(6004,'2022-12-31','Encerrado','2021-01-01',365,4444,'12345678900004'),(6005,'2023-09-30','Ativo','2021-01-01',637,5555,'12345678900005'),(6006,'2024-12-31','Ativo','2022-01-01',731,6666,'12345678900006'),(6007,'2023-12-31','Encerrado','2021-01-01',730,7777,'12345678900007'),(6008,'2024-06-30','Ativo','2022-01-01',546,8888,'12345678900008'),(6009,'2023-12-31','Encerrado','2021-01-01',730,9999,'12345678900009'),(6010,'2023-09-30','Ativo','2021-01-01',637,0,'12345678900010');
/*!40000 ALTER TABLE `contrato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver` (
  `COD_COMPONENTE` int NOT NULL,
  `SEQUENCIAL` int NOT NULL,
  `CAMINHO` varchar(100) NOT NULL,
  PRIMARY KEY (`COD_COMPONENTE`,`SEQUENCIAL`),
  CONSTRAINT `driver_ibfk_1` FOREIGN KEY (`COD_COMPONENTE`) REFERENCES `componente` (`COD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver`
--

LOCK TABLES `driver` WRITE;
/*!40000 ALTER TABLE `driver` DISABLE KEYS */;
INSERT INTO `driver` VALUES (1,1,'C:/drivers/audio/'),(2,2,'C:/drivers/video/'),(3,3,'C:/drivers/rede/'),(4,1,'D:/drivers/audio/'),(5,2,'D:/drivers/video/'),(6,1,'E:/drivers/rede/'),(7,2,'E:/drivers/audio/'),(8,3,'E:/drivers/video/'),(9,4,'E:/drivers/outros/'),(10,1,'F:/drivers/video/');
/*!40000 ALTER TABLE `driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver_impressora`
--

DROP TABLE IF EXISTS `driver_impressora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver_impressora` (
  `COD_IMPRESSORA` int NOT NULL,
  `COD_DRIVER` int NOT NULL,
  `VERSAO` varchar(20) NOT NULL,
  `CAMINHO` varchar(100) NOT NULL,
  `IMPRESSORA` int NOT NULL,
  PRIMARY KEY (`COD_IMPRESSORA`,`COD_DRIVER`),
  KEY `COD_DRIVER` (`COD_DRIVER`),
  CONSTRAINT `driver_impressora_ibfk_1` FOREIGN KEY (`COD_IMPRESSORA`) REFERENCES `impressora` (`COD`),
  CONSTRAINT `driver_impressora_ibfk_2` FOREIGN KEY (`COD_DRIVER`) REFERENCES `driver` (`COD_COMPONENTE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver_impressora`
--

LOCK TABLES `driver_impressora` WRITE;
/*!40000 ALTER TABLE `driver_impressora` DISABLE KEYS */;
INSERT INTO `driver_impressora` VALUES (1,1,'v1.0','C:driversprinter1',1),(2,2,'v2.0','C:driversprinter1',1),(3,3,'v3.5','C:driversprinter2',2),(4,4,'v4.0','C:driversprinter2',2),(5,5,'v1.2','C:driversprinter3',3),(6,6,'v2.1','C:driversprinter3',3),(7,7,'v2.0','C:driversprinter4',4),(8,8,'v3.0','C:driversprinter4',4),(9,9,'v1.0','C:driversprinter5',5),(10,10,'v2.0','C:driversprinter5',5);
/*!40000 ALTER TABLE `driver_impressora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `envolveu_ordem_servico_impressora`
--

DROP TABLE IF EXISTS `envolveu_ordem_servico_impressora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `envolveu_ordem_servico_impressora` (
  `cod_impressora` int NOT NULL,
  `num_ordem` int NOT NULL,
  PRIMARY KEY (`cod_impressora`,`num_ordem`),
  KEY `FK_ENVOLVEU_ORDEM_SERVICO_IMPRESSORA_IMPRESSORA_IDX` (`cod_impressora`),
  KEY `FK_ENVOLVEU_ORDEM_SERVICO_IMPRESSORA_ORDEM_SERVICO_IDX` (`num_ordem`),
  CONSTRAINT `envolveu_ordem_servico_impressora_ibfk_1` FOREIGN KEY (`cod_impressora`) REFERENCES `impressora` (`COD`),
  CONSTRAINT `envolveu_ordem_servico_impressora_ibfk_2` FOREIGN KEY (`num_ordem`) REFERENCES `ordem_servico` (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `envolveu_ordem_servico_impressora`
--

LOCK TABLES `envolveu_ordem_servico_impressora` WRITE;
/*!40000 ALTER TABLE `envolveu_ordem_servico_impressora` DISABLE KEYS */;
INSERT INTO `envolveu_ordem_servico_impressora` VALUES (1,10),(2,9),(3,8),(4,7),(5,6),(6,5),(7,4),(8,3),(9,2),(10,1);
/*!40000 ALTER TABLE `envolveu_ordem_servico_impressora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fatura`
--

DROP TABLE IF EXISTS `fatura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fatura` (
  `cod` int NOT NULL,
  `n_parcelas` int NOT NULL,
  `vl_total` decimal(10,2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `cod_cliente_pj` int NOT NULL,
  PRIMARY KEY (`cod`),
  KEY `cod_cliente_pj` (`cod_cliente_pj`),
  CONSTRAINT `fatura_ibfk_1` FOREIGN KEY (`cod_cliente_pj`) REFERENCES `cliente_pj` (`Cod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fatura`
--

LOCK TABLES `fatura` WRITE;
/*!40000 ALTER TABLE `fatura` DISABLE KEYS */;
INSERT INTO `fatura` VALUES (1,2,100.00,'Pendente',1),(2,3,150.50,'Pago',2),(3,1,50.00,'Pendente',3),(4,6,500.00,'Em aberto',4),(5,4,200.00,'Pago',6),(6,2,1000.00,'Em aberto',7),(7,3,300.50,'Pendente',8),(8,1,100.00,'Pago',10),(9,5,800.00,'Em aberto',6),(10,4,250.00,'Pago',5),(1510,4,250.00,'Pago',0),(1511,2,100.00,'Pendente',1111),(1512,3,150.50,'Pago',2222),(1513,1,50.00,'Pendente',3333),(1514,6,500.00,'Pago',4444),(1515,4,200.00,'Pago',5555),(1516,2,1000.00,'Pendente',6666),(1517,3,300.50,'Pendente',7777),(1518,1,100.00,'Pago',8888),(1519,5,800.00,'Pendente',9999);
/*!40000 ALTER TABLE `fatura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impressora`
--

DROP TABLE IF EXISTS `impressora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `impressora` (
  `COD` int NOT NULL,
  `ESTADO` varchar(20) NOT NULL,
  `FABRICANTE` varchar(50) NOT NULL,
  `DATA_ENTRADA` date NOT NULL,
  `SETOR` varchar(50) NOT NULL,
  `DESCRICAO` varchar(100) NOT NULL,
  `HISTORICO` varchar(100) NOT NULL,
  `MODELO` varchar(50) NOT NULL,
  `COD_CONTRATO` int NOT NULL,
  PRIMARY KEY (`COD`),
  KEY `COD_CONTRATO` (`COD_CONTRATO`),
  CONSTRAINT `impressora_ibfk_1` FOREIGN KEY (`COD_CONTRATO`) REFERENCES `contrato` (`COD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impressora`
--

LOCK TABLES `impressora` WRITE;
/*!40000 ALTER TABLE `impressora` DISABLE KEYS */;
INSERT INTO `impressora` VALUES (1,'Bom','HP','2022-01-15','RH','Impressora a laser','Manutenção realizada em janeiro de 2023','LaserJet Pro MFP M426fdw',1),(2,'Ruim','Brother','2021-06-01','Financeiro','Impressora a jato de tinta','Precisa de manutenção','MFC-J6935DW',2),(3,'Bom','Epson','2021-12-01','TI','Impressora matricial','Sem histórico de manutenção','LQ-590II',3),(4,'Bom','Samsung','2022-02-01','Compras','Impressora a laser colorida','Manutenção realizada em fevereiro de 2023','Xpress C430W',1),(5,'Ruim','Lexmark','2022-03-01','Marketing','Impressora a jato de tinta','Precisa de manutenção','CX517de',5),(6,'Bom','Canon','2021-09-01','Jurídico','Impressora a laser','Manutenção realizada em março de 2022','imageRUNNER ADVANCE C256i III',6),(7,'Bom','Xerox','2022-02-15','RH','Impressora multifuncional a laser','Manutenção realizada em fevereiro de 2023','WorkCentre 6515',4),(8,'Bom','Dell','2021-11-15','TI','Impressora a jato de tinta','Manutenção realizada em dezembro de 2021','V525w',8),(9,'Bom','Ricoh','2022-02-28','Administração','Impressora multifuncional a laser','Manutenção realizada em março de 2023','SP C261SFNw',4),(10,'Bom','HP','2021-05-15','Jurídico','Impressora a laser','Manuteção realizada em março de 2022','LaserJet Pro MFP M426fdw',2);
/*!40000 ALTER TABLE `impressora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kpi`
--

DROP TABLE IF EXISTS `kpi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kpi` (
  `matric_tec` int NOT NULL,
  `Sequencial` int NOT NULL,
  `KPI_1` int NOT NULL,
  `dsc_KPI_1` varchar(50) NOT NULL,
  `KPI_2` int NOT NULL,
  `dsc_KPI_2` varchar(50) NOT NULL,
  PRIMARY KEY (`matric_tec`,`Sequencial`),
  CONSTRAINT `kpi_ibfk_1` FOREIGN KEY (`matric_tec`) REFERENCES `tecnico` (`Matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kpi`
--

LOCK TABLES `kpi` WRITE;
/*!40000 ALTER TABLE `kpi` DISABLE KEYS */;
INSERT INTO `kpi` VALUES (1,1,10,'Número de vendas',20,'Valor total das vendas'),(2,2,8,'Tempo médio de atendimento',15,'Satisfação do cliente'),(3,1,5,'Número de chamados resolvidos',10,'Tempo médio de resolução'),(4,2,6,'Nível de aderência ao SLA',12,'Taxa de resolução no primeiro contato'),(5,1,15,'Número de novos clientes',25000,'Receita total'),(6,2,80,'Taxa de conversão',30,'Custo de aquisição do cliente'),(7,1,50,'Retorno sobre o investimento',100,'Margem de lucro'),(8,2,200,'Custo por clique',500,'Taxa de conversão'),(9,1,12,'Tempo médio de resposta',20,'Número de tickets abertos'),(10,2,7,'Taxa de resolução',90,'Índice de satisfação do cliente');
/*!40000 ALTER TABLE `kpi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orcamento`
--

DROP TABLE IF EXISTS `orcamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orcamento` (
  `COD` int NOT NULL,
  `DATA_ABERTURA` date NOT NULL,
  `DT_EMISSAO` date NOT NULL,
  `DESCRICAO` varchar(100) NOT NULL,
  `VALIDADE_N_DIAS` int NOT NULL,
  `ULTIMA_DATA` date NOT NULL,
  PRIMARY KEY (`COD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orcamento`
--

LOCK TABLES `orcamento` WRITE;
/*!40000 ALTER TABLE `orcamento` DISABLE KEYS */;
INSERT INTO `orcamento` VALUES (1,'2022-01-01','2022-01-05','Orçamento para aquisição de Placa',30,'2022-01-31'),(2,'2022-02-01','2022-02-05','Orçamento para compra de material para manutenção',15,'2022-02-20'),(3,'2022-03-01','2022-03-10','Orçamento para serviços de limpeza',60,'2022-05-10'),(4,'2022-04-01','2022-04-05','Orçamento para aquisição de equipamentos de informática',30,'2022-05-05'),(5,'2022-05-01','2022-05-05','Orçamento para conserto da estrutura do equipamento',90,'2022-07-30'),(6,'2022-06-01','2022-06-05','Orçamento para atendimento homeOff',15,'2022-06-20'),(7,'2022-07-01','2022-07-05','Orçamento para contratação de serviços',30,'2022-08-05'),(8,'2022-08-01','2022-08-05','Orçamento para Analisar atividade',15,'2022-08-20'),(9,'2022-09-01','2022-09-05','Orçamento para contratação de serviços externo',30,'2022-10-05'),(10,'2022-10-01','2022-10-05','Orçamento para aquisição de software de gestão',60,'2022-12-05');
/*!40000 ALTER TABLE `orcamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordem_servico`
--

DROP TABLE IF EXISTS `ordem_servico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordem_servico` (
  `numero` int NOT NULL,
  `status` varchar(20) NOT NULL,
  `data_criacao` date NOT NULL,
  `prazo_entrega_em_dias` int NOT NULL,
  `dt_devida` date NOT NULL,
  `cod_orcamento` int NOT NULL,
  `cod_fatura` int NOT NULL,
  `cod_chamado` int NOT NULL,
  PRIMARY KEY (`numero`),
  KEY `cod_orcamento` (`cod_orcamento`),
  KEY `cod_fatura` (`cod_fatura`),
  KEY `cod_chamado` (`cod_chamado`),
  CONSTRAINT `ordem_servico_ibfk_1` FOREIGN KEY (`cod_orcamento`) REFERENCES `orcamento` (`COD`),
  CONSTRAINT `ordem_servico_ibfk_2` FOREIGN KEY (`cod_fatura`) REFERENCES `fatura` (`cod`),
  CONSTRAINT `ordem_servico_ibfk_3` FOREIGN KEY (`cod_chamado`) REFERENCES `chamado` (`Seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordem_servico`
--

LOCK TABLES `ordem_servico` WRITE;
/*!40000 ALTER TABLE `ordem_servico` DISABLE KEYS */;
INSERT INTO `ordem_servico` VALUES (1,'Aberto','2023-03-18',5,'2023-03-23',1,1,1),(2,'Fechado','2023-03-15',3,'2023-03-18',2,2,2),(3,'Pendente','2023-03-10',10,'2023-03-20',3,3,1),(4,'Em Andamento','2023-03-08',7,'2023-03-23',4,4,4),(5,'Aberto','2023-03-17',2,'2023-03-19',3,3,5),(6,'Fechado','2023-03-12',4,'2023-03-23',6,6,6),(7,'Pendente','2023-03-09',8,'2023-03-17',1,7,1),(8,'Em Andamento','2023-03-07',6,'2023-03-23',2,8,4),(9,'Aberto','2023-03-16',1,'2023-03-17',9,9,2),(10,'Fechado','2023-03-14',2,'2023-03-16',1,1,1);
/*!40000 ALTER TABLE `ordem_servico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `possui_componente_computador`
--

DROP TABLE IF EXISTS `possui_componente_computador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `possui_componente_computador` (
  `cod_comp` int NOT NULL,
  `cod_computador` int NOT NULL,
  PRIMARY KEY (`cod_comp`,`cod_computador`),
  KEY `FK_POSSUI_COMPONENTE_COMPUTADOR_COMPONENTE_IDX` (`cod_comp`),
  KEY `FK_POSSUI_COMPONENTE_COMPUTADOR_COMPUTADOR_IDX` (`cod_computador`),
  CONSTRAINT `possui_componente_computador_ibfk_1` FOREIGN KEY (`cod_comp`) REFERENCES `componente` (`COD`),
  CONSTRAINT `possui_componente_computador_ibfk_2` FOREIGN KEY (`cod_computador`) REFERENCES `computador` (`COD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `possui_componente_computador`
--

LOCK TABLES `possui_componente_computador` WRITE;
/*!40000 ALTER TABLE `possui_componente_computador` DISABLE KEYS */;
INSERT INTO `possui_componente_computador` VALUES (1,10),(2,9),(3,8),(4,7),(5,6),(6,5),(7,4),(8,3),(9,2),(10,1);
/*!40000 ALTER TABLE `possui_componente_computador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `relatorio_01`
--

DROP TABLE IF EXISTS `relatorio_01`;
/*!50001 DROP VIEW IF EXISTS `relatorio_01`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `relatorio_01` AS SELECT 
 1 AS `cod_chamado`,
 1 AS `ordem`,
 1 AS `cliente`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `relatorio_02`
--

DROP TABLE IF EXISTS `relatorio_02`;
/*!50001 DROP VIEW IF EXISTS `relatorio_02`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `relatorio_02` AS SELECT 
 1 AS `Cliente`,
 1 AS `cod_chamado`,
 1 AS `Ordem`,
 1 AS `Descricao_do_servico`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `relatorio_03`
--

DROP TABLE IF EXISTS `relatorio_03`;
/*!50001 DROP VIEW IF EXISTS `relatorio_03`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `relatorio_03` AS SELECT 
 1 AS `Dt_contrato`,
 1 AS `Registro_cotrato`,
 1 AS `Cliente`,
 1 AS `Tipo`,
 1 AS `Status_impr`,
 1 AS `Status_PC`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `relatorio_04`
--

DROP TABLE IF EXISTS `relatorio_04`;
/*!50001 DROP VIEW IF EXISTS `relatorio_04`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `relatorio_04` AS SELECT 
 1 AS `Matricula`,
 1 AS `login`,
 1 AS `no_consertos`,
 1 AS `matric_supervisor`,
 1 AS `seq`,
 1 AS `mat_supervisor`,
 1 AS `cod_cliente_pj`,
 1 AS `numero`,
 1 AS `status`,
 1 AS `dt_devida`,
 1 AS `codigo_serv`,
 1 AS `valor`,
 1 AS `situacao`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `servico`
--

DROP TABLE IF EXISTS `servico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servico` (
  `cod` int NOT NULL,
  `descricao` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `cod_tipo_servico` int NOT NULL,
  `num_serv` int NOT NULL,
  `nivel_urgencia` int NOT NULL,
  PRIMARY KEY (`cod`),
  KEY `cod_tipo_servico` (`cod_tipo_servico`),
  KEY `num_serv` (`num_serv`),
  CONSTRAINT `servico_ibfk_1` FOREIGN KEY (`cod_tipo_servico`) REFERENCES `tipo_servico` (`COD`),
  CONSTRAINT `servico_ibfk_2` FOREIGN KEY (`num_serv`) REFERENCES `ordem_servico` (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servico`
--

LOCK TABLES `servico` WRITE;
/*!40000 ALTER TABLE `servico` DISABLE KEYS */;
INSERT INTO `servico` VALUES (1,'Manutenção de impressora','Pendente',250.00,1,1,3),(2,'Formatação de computador','Concluído',150.00,2,2,2),(3,'Instalação de software','Pendente',80.00,3,3,1),(4,'Configuração de rede','Pendente',300.00,4,4,3),(5,'Substituição de placa mãe','Concluído',500.00,5,5,2),(6,'Recuperação de dados','Pendente',200.00,6,6,1),(7,'Atualização de sistema operacional','Pendente',120.00,3,7,2),(8,'Troca de tela de notebook','Concluído',350.00,5,8,3),(9,'Limpeza de vírus','Concluído',100.00,2,9,1),(10,'Instalação de antivírus','Pendente',60.00,3,10,2);
/*!40000 ALTER TABLE `servico` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `servico_AFTER_UPDATE` AFTER UPDATE ON `servico` FOR EACH ROW BEGIN
	if new.status = "Concluído" then
		UPDATE kpi set KPI_1 = KPI_1 + 1;	
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `supervisor`
--

DROP TABLE IF EXISTS `supervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supervisor` (
  `Matricula` int NOT NULL,
  `login` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `CPF` char(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `carga_horaria` int NOT NULL,
  `unidade` char(14) NOT NULL,
  PRIMARY KEY (`Matricula`),
  KEY `unidade` (`unidade`),
  CONSTRAINT `supervisor_ibfk_1` FOREIGN KEY (`unidade`) REFERENCES `unidade_suporte` (`CNPJ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supervisor`
--

LOCK TABLES `supervisor` WRITE;
/*!40000 ALTER TABLE `supervisor` DISABLE KEYS */;
INSERT INTO `supervisor` VALUES (1,'joaosilva','123456','João Silva','11122233344','joao.silva@example.com',40,'01234567890123'),(2,'mariaalves','abcdef','Maria Alves','22233344455','maria.alves@example.com',35,'01234567890123'),(3,'pedrosouza','qwerty','Pedro Souza','33344455566','pedro.souza@example.com',30,'01234567890123'),(4,'anacarvalho','123abc','Ana Carvalho','44455566677','ana.carvalho@example.com',40,'01234567890123'),(5,'felipeazevedo','xyz123','Felipe Azevedo','55566677788','felipe.azevedo@example.com',35,'01234567890123'),(6,'juliasantos','456789','Julia Santos','66677788899','julia.santos@example.com',30,'01234567890123'),(7,'carloslima','abc123','Carlos Lima','77788899900','carlos.lima@example.com',40,'01234567890123'),(8,'amandarodrigues','789xyz','Amanda Rodrigues','88899900011','amanda.rodrigues@example.com',35,'01234567890123'),(9,'renatapereira','pqr123','Renata Pereira','99900011122','renata.pereira@example.com',30,'01234567890123'),(10,'lucasoliveira','456def','Lucas Oliveira','00011122233','lucas.oliveira@example.com',40,'01234567890123'),(1001,'joaosilva','123456','João Santos','11122233344','joao.Santos@example.com',40,'12345678900001'),(1002,'mariaalves','abcdef','Maria Alves','22233344455','maria.alves@example.com',35,'12345678900002'),(1003,'pedrosouza','qwerty','Pedro Souza','33344455566','pedro.souza@example.com',30,'12345678900003'),(1004,'anacarvalho','123abc','Ana Carvalho','44455566677','ana.carvalho@example.com',40,'12345678900004'),(1005,'felipeazevedo','xyz123','Felipe Azevedo','55566677788','felipe.azevedo@example.com',35,'12345678900005'),(1006,'juliasantos','456789','Julia Santos','66677788899','julia.santos@example.com',30,'12345678900006'),(1007,'carloslima','abc123','Carlos Lima','77788899900','carlos.lima@example.com',40,'12345678900007'),(1008,'amandarodrigues','789xyz','Amanda Rodrigues','88899900011','amanda.rodrigues@example.com',35,'12345678900008'),(1009,'renatapereira','pqr123','Renata Pereira','99900011122','renata.pereira@example.com',30,'12345678900009'),(1010,'lucasoliveira','456def','Lucas Oliveira','00011122233','lucas.oliveira@example.com',40,'12345678900010');
/*!40000 ALTER TABLE `supervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecnico`
--

DROP TABLE IF EXISTS `tecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tecnico` (
  `Matricula` int NOT NULL,
  `login` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `CPF` char(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `carga_horaria` int NOT NULL,
  `no_consertos` int NOT NULL,
  `dias_trabalhados` int NOT NULL,
  `no_voltas` int NOT NULL,
  `matric_supervisor` int NOT NULL,
  `data_inicio` date NOT NULL,
  `unidade` char(14) NOT NULL,
  PRIMARY KEY (`Matricula`),
  KEY `matric_supervisor` (`matric_supervisor`),
  KEY `unidade` (`unidade`),
  CONSTRAINT `tecnico_ibfk_1` FOREIGN KEY (`matric_supervisor`) REFERENCES `supervisor` (`Matricula`),
  CONSTRAINT `tecnico_ibfk_2` FOREIGN KEY (`unidade`) REFERENCES `unidade_suporte` (`CNPJ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecnico`
--

LOCK TABLES `tecnico` WRITE;
/*!40000 ALTER TABLE `tecnico` DISABLE KEYS */;
INSERT INTO `tecnico` VALUES (1,'tecnico1','senha1','João Silva','11122233344','joao.silva@email.com',40,5,20,2,10,'2022-01-01','12345678901234'),(2,'tecnico2','senha2','Maria Souza','22233344455','maria.souza@email.com',40,8,22,4,10,'2022-01-01','23456789012345'),(3,'tecnico3','senha3','Pedro Santos','33344455566','pedro.santos@email.com',40,10,25,3,1,'2022-01-01','34567890123456'),(4,'tecnico4','senha4','Ana Oliveira','44455566677','ana.oliveira@email.com',40,6,18,1,1,'2022-01-01','45678901234567'),(5,'tecnico5','senha5','Fernando Silva','55566677788','fernando.silva@email.com',40,9,23,5,2,'2022-01-01','56789012345678'),(6,'tecnico6','senha6','Juliana Santos','66677788899','juliana.santos@email.com',40,7,21,3,2,'2022-01-01','67890123456789'),(7,'tecnico7','senha7','Márcio Almeida','77788899900','marcio.almeida@email.com',40,12,27,6,3,'2022-01-01','78901234567890'),(8,'tecnico8','senha8','Camila Lima','88899900011','camila.lima@email.com',40,4,15,2,3,'2022-01-01','89012345678901'),(9,'tecnico9','senha9','Rafaela Sousa','99900011122','rafaela.sousa@email.com',40,11,26,4,4,'2022-01-01','90123456789012'),(10,'tecnico10','senha10','Gustavo Silva','00011122233','gustavo.silva@email.com',40,5,19,1,4,'2022-01-01','01234567890123');
/*!40000 ALTER TABLE `tecnico` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `tecnico_AFTER_INSERT` AFTER INSERT ON `tecnico` FOR EACH ROW BEGIN
		if new.Matricula != 0 then
			UPDATE unidade_suporte set NroFuncionarios = NroFuncionarios + 1 where CNPJ = new.unidade;	
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `tipo_servico`
--

DROP TABLE IF EXISTS `tipo_servico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_servico` (
  `COD` int NOT NULL,
  `DESCRICAO` varchar(100) NOT NULL,
  PRIMARY KEY (`COD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_servico`
--

LOCK TABLES `tipo_servico` WRITE;
/*!40000 ALTER TABLE `tipo_servico` DISABLE KEYS */;
INSERT INTO `tipo_servico` VALUES (1,'Limpeza de placa'),(2,'Teste de hardware'),(3,'Montagem de equipamente'),(4,'Manutenção elétrica'),(5,'Manutenção elétronica'),(6,'Modelagem de circuitos'),(7,'Serviços de limpeza de componetes'),(8,'Restauração de placas'),(9,'Consultoria de negócios'),(10,'Serviços de informática');
/*!40000 ALTER TABLE `tipo_servico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidade_suporte`
--

DROP TABLE IF EXISTS `unidade_suporte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidade_suporte` (
  `CNPJ` char(14) NOT NULL,
  `estado` char(2) NOT NULL,
  `end` varchar(100) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `Matriz` char(14) NOT NULL,
  `razao_social` varchar(50) NOT NULL,
  `NroFuncionarios` int NOT NULL,
  PRIMARY KEY (`CNPJ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidade_suporte`
--

LOCK TABLES `unidade_suporte` WRITE;
/*!40000 ALTER TABLE `unidade_suporte` DISABLE KEYS */;
INSERT INTO `unidade_suporte` VALUES ('01234567890123','MG','Praça J, 2223','Unidade 10','56789012345678','Empresa 5',70),('12345678900001','SP','Rua A, 123','Unidade 1','98765432109876','Empresa 1',50),('12345678900002','RJ','Av. B, 456','Unidade 2','98765432109876','Empresa 2',75),('12345678900003','MG','Praça C, 789','Unidade 3','23456789012345','Empresa 3',30),('12345678900004','SP','Rua D, 1011','Unidade 4','23456789012345','Empresa 4',60),('12345678900005','PR','Rua E, 1213','Unidade 5','34567890123456','Empresa 5',20),('12345678900006','RS','Av. F, 1415','Unidade 6','34567890123456','Empresa 6',45),('12345678900007','SC','Rua G, 1617','Unidade 7','45678901234567','Empresa 7',55),('12345678900008','SP','Av. H, 1819','Unidade 8','45678901234567','Empresa 8',90),('12345678900009','RJ','Rua I, 2021','Unidade 9','56789012345678','Empresa 9',25),('12345678900010','MG','Praça J, 2223','Unidade 10','56789012345678','Empresa 10',70),('12345678901234','SP','Rua A, 123','Unidade 1','98765432109876','Empresa 1',50),('23456789012345','RJ','Av. B, 456','Unidade 2','98765432109876','Empresa 1',75),('34567890123456','MG','Praça C, 789','Unidade 3','23456789012345','Empresa 2',30),('45678901234567','SP','Rua D, 1011','Unidade 4','23456789012345','Empresa 2',60),('56789012345678','PR','Rua E, 1213','Unidade 5','34567890123456','Empresa 3',20),('67890123456789','RS','Av. F, 1415','Unidade 6','34567890123456','Empresa 3',45),('78901234567890','SC','Rua G, 1617','Unidade 7','45678901234567','Empresa 4',55),('89012345678901','SP','Av. H, 1819','Unidade 8','45678901234567','Empresa 4',90),('90123456789012','RJ','Rua I, 2021','Unidade 9','56789012345678','Empresa 5',25);
/*!40000 ALTER TABLE `unidade_suporte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'helpdesk'
--

--
-- Dumping routines for database 'helpdesk'
--
/*!50003 DROP FUNCTION IF EXISTS `contrato_em_dia` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `contrato_em_dia`(cod_cliente INT) RETURNS varchar(100) CHARSET utf8mb4
    DETERMINISTIC
begin
DECLARE v_dt_fim DATE;

SELECT dt_fim INTO v_dt_fim FROM contrato WHERE COD_CLIENTE_PJ = cod_cliente ;
    IF v_dt_fim < curdate() THEN
         RETURN CONCAT(' Contrato número ' , cod_cliente , ' esta vencido.');
    elseif v_dt_fim >= curdate() then
		return concat(' Contrato número ', cod_cliente , ' esta em dia.');
    ELSE
        RETURN concat('Contrato Inesistente');
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `verificar_fatura` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `verificar_fatura`(num_fatura INT) RETURNS varchar(100) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE ordem_status VARCHAR(20);
    DECLARE fatura_status VARCHAR(20);
    declare numero_os int;
    SELECT os.status, os.numero INTO ordem_status, numero_os FROM ORDEM_SERVICO os WHERE os.cod_fatura = num_fatura;
    SELECT f.status INTO fatura_status FROM FATURA f WHERE f.cod = num_fatura;
    
    IF ordem_status = 'fechado' AND fatura_status = 'pendente' THEN
        RETURN CONCAT('Fatura número ', num_fatura, ' deve ser emitida ordem de serviço número  ', numero_os  , ' esta concluida.');
    ELSEIF ordem_status != 'fechado' THEN
        RETURN concat('Ordem de serviço  ' , numero_os , ' não está concluida fatura não pode ser emitida.');
    ELSE
        RETURN 'Fatura já emitida ou não encontrada.';
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `atualizar_faturas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `atualizar_faturas`()
BEGIN

    DECLARE vt varchar(20) ;
    DECLARE fc int default 0;
    DECLARE fimloop int default 0;
    
    DECLARE mycur CURSOR FOR  SELECT o.status, f.cod from ordem_servico o 
	inner join fatura f on f.cod = o.cod_fatura
	where o.status = "Fechado" and f.status = "Pendente";

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET fimloop = 1;
    
start transaction ;    
    OPEN mycur;
    WHILE(fimloop != 1 )DO
		FETCH mycur INTO vt,fc;
        UPDATE fatura 
        set status = "Pago" 
        where cod = fc; 
    END WHILE;
    select * from ordem_servico o 
	inner join fatura f on f.cod = o.cod_fatura;
rollback;
   
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `generate_KPI_row` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `generate_KPI_row`(
  IN start_date DATE,
  IN end_date DATE
)
BEGIN
	DECLARE tech_id INT;
    DECLARE cham_prior INT;
	DECLARE ord_ser_fin INT;
    DECLARE tempo_fin INT;
    
	DECLARE fimloop int default 0;
	
    DECLARE mycur CURSOR FOR SELECT  tech.Matricula, tech.carga_horaria, tech.no_consertos,tech.dias_trabalhados FROM TECNICO AS tech
    inner join chamado as ch on tech.Matricula = ch.mat_tec
    inner JOIN ORDEM_SERVICO AS os ON os.cod_chamado = ch.seq
    WHERE os.data_criacao BETWEEN start_date AND end_date;
  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET fimloop = 1;


  CREATE TEMPORARY TABLE temp_KPI (
    technician_id INT,
    total_tickets INT,
    total_completed_tickets INT,
    total_time_spent INT,
    PRIMARY KEY (technician_id)
  );

    OPEN mycur;
    WHILE(fimloop != 1 )DO
    FETCH mycur INTO tech_id, cham_prior, ord_ser_fin, tempo_fin;
    
  
	if fimloop != 1 then
		INSERT INTO temp_KPI (technician_id, total_tickets, total_completed_tickets, total_time_spent)
		value (tech_id, cham_prior, ord_ser_fin, tempo_fin);
    end if;
    
    END WHILE;
	CLOSE mycur;
	
 
  SELECT DISTINCT technician_id, total_tickets, total_completed_tickets, total_time_spent
  FROM temp_KPI;

  DROP TABLE temp_KPI;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `relatorio_01`
--

/*!50001 DROP VIEW IF EXISTS `relatorio_01`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `relatorio_01` AS select `ordem_servico`.`cod_chamado` AS `cod_chamado`,count(`ordem_servico`.`cod_chamado`) AS `ordem`,`chamado`.`cod_cliente_pj` AS `cliente` from (`ordem_servico` left join `chamado` on((`ordem_servico`.`cod_chamado` = `chamado`.`cod_cliente_pj`))) where (`ordem_servico`.`dt_devida` between '2023-03-18' and '2023-03-23') group by `ordem_servico`.`cod_chamado` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `relatorio_02`
--

/*!50001 DROP VIEW IF EXISTS `relatorio_02`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `relatorio_02` AS select `chamado`.`cod_cliente_pj` AS `Cliente`,`ordem_servico`.`cod_chamado` AS `cod_chamado`,sum(`ordem_servico`.`cod_chamado`) AS `Ordem`,`tipo_servico`.`COD` AS `Descricao_do_servico` from ((`ordem_servico` left join `chamado` on((`ordem_servico`.`cod_chamado` = `chamado`.`cod_cliente_pj`))) join `tipo_servico` on((`ordem_servico`.`cod_chamado` = `tipo_servico`.`COD`))) where (year(`ordem_servico`.`dt_devida`) = 2023) group by `ordem_servico`.`cod_chamado` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `relatorio_03`
--

/*!50001 DROP VIEW IF EXISTS `relatorio_03`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `relatorio_03` AS select `contrato`.`DT_INICIO` AS `Dt_contrato`,`contrato`.`COD` AS `Registro_cotrato`,`cliente_pj`.`Cod` AS `Cliente`,`cliente_pj`.`prioridade` AS `Tipo`,`impressora`.`ESTADO` AS `Status_impr`,`computador`.`ESTADO` AS `Status_PC` from ((`contrato` left join `cliente_pj` on((`contrato`.`COD` = `cliente_pj`.`Cod`))) join (`impressora` left join `computador` on((`impressora`.`ESTADO` = `computador`.`ESTADO`)))) where (year(`contrato`.`DT_INICIO`) = 2021) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `relatorio_04`
--

/*!50001 DROP VIEW IF EXISTS `relatorio_04`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `relatorio_04` AS select `tecnico`.`Matricula` AS `Matricula`,`tecnico`.`login` AS `login`,`tecnico`.`no_consertos` AS `no_consertos`,`tecnico`.`matric_supervisor` AS `matric_supervisor`,`chamado`.`Seq` AS `seq`,`chamado`.`mat_supervisor` AS `mat_supervisor`,`chamado`.`cod_cliente_pj` AS `cod_cliente_pj`,`ordem_servico`.`numero` AS `numero`,`ordem_servico`.`status` AS `status`,`ordem_servico`.`dt_devida` AS `dt_devida`,`servico`.`cod` AS `codigo_serv`,`servico`.`valor` AS `valor`,`servico`.`status` AS `situacao` from ((`ordem_servico` join `servico`) join (`tecnico` join `chamado` on((`tecnico`.`Matricula` = `chamado`.`mat_tec`)))) where (`ordem_servico`.`dt_devida` between '2023-03-22' and '2023-03-23') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-22 17:59:28
